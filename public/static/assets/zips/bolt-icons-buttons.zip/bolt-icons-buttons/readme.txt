Lightning Bolt Icons/Buttons Collection

Created by pix3lcat (pix3lcat.github.io) on 12-04-2019

This package includes a collection of icons/buttons for game ui/objects. Use them to create awesome stuff!

Included:
    Separate PNG files
    Vector file(s)
Want to encourage the creation of free game assets? you can :)

    https://www.paypal.me/pix3lcat